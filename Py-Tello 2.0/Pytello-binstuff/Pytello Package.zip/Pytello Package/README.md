# Read Me
For this  to work you need Python 3.6 and above and Windows 10. At the begining of the your file you create you need to add the following command:

import pytello-hsu

Also to get this on your computer you need to do the following command:

pip install pytello-hsu

When programming you must use the "init()" command at the begining of the file if you want the program to work unless you know what your doing and how the program works. To undersand how the program works further look at DOCUMENTATION.md.